'use client';

import { useEffect, useState } from 'react';

interface ShareModalProps {
  story: {
    id: string;
    shareCode: string;
  };
  onClose: () => void;
}

export default function ShareModal({ story, onClose }: ShareModalProps) {
  const [shareUrl, setShareUrl] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const url = `${window.location.origin}/join/${story.shareCode}`;
      setShareUrl(url);
    }
  }, [story.shareCode]);

  const handleCopy = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl p-8 max-w-md w-full">
        <h2 className="text-3xl font-bold text-purple-900 mb-4">🎉 Share Your Story</h2>

        <p className="text-lg text-gray-800 mb-6 font-semibold">
          Invite friends to join and create this story together!
        </p>

        <div className="bg-purple-50 border-2 border-purple-300 rounded-lg p-4 mb-4">
          <p className="text-sm font-bold text-purple-700 mb-2">Share Code:</p>
          <p className="text-2xl font-mono font-bold text-purple-900 break-all">{story.shareCode}</p>
        </div>

        <div className="bg-blue-50 border-2 border-blue-300 rounded-lg p-4 mb-6">
          <p className="text-sm font-bold text-blue-700 mb-2">Share Link:</p>
          <p className="text-base font-mono text-blue-900 break-all">{shareUrl}</p>
        </div>

        <div className="space-y-3">
          <button
            onClick={handleCopy}
            className={`w-full py-3 rounded-lg font-bold transition text-lg ${
              copied
                ? 'bg-green-500 text-white'
                : 'bg-blue-600 hover:bg-blue-700 text-white'
            }`}
          >
            {copied ? '✓ Copied to Clipboard!' : '📋 Copy Link'}
          </button>

          <button
            onClick={() => {
              const text = `Join my Mad Libs story! ${shareUrl}`;
              if (navigator.share) {
                navigator.share({
                  title: 'Mad Libs Story',
                  text: text,
                });
              } else {
                handleCopy();
              }
            }}
            className="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg font-bold transition text-lg"
          >
            📤 Share
          </button>

          <button
            onClick={onClose}
            className="w-full bg-gray-300 hover:bg-gray-400 text-gray-900 py-3 rounded-lg font-bold transition text-lg"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
