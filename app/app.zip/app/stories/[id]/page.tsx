'use client';

import { useEffect, useState } from 'react';
import { useParams, useSearchParams } from 'next/navigation';
import StoryEditor from '@/app/components/StoryEditor';

interface Story {
  id: string;
  title: string;
  content: string;
  shareCode: string;
  players: Array<{ id: string; name: string }>;
  turns: Array<{ id: string; content: string; order: number }>;
}

interface Player {
  id: string;
  name: string;
  storyId: string;
}

export default function StoryPage() {
  const params = useParams();
  const searchParams = useSearchParams();
  const storyId = params.id as string;
  const playerNameParam = searchParams.get('playerName');

  const [story, setStory] = useState<Story | null>(null);
  const [player, setPlayer] = useState<Player | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isAddingTurn, setIsAddingTurn] = useState(false);

  useEffect(() => {
    const fetchStory = async () => {
      try {
        const response = await fetch(`/api/stories/${storyId}`);
        if (!response.ok) throw new Error('Story not found');

        const data = await response.json();
        setStory(data);

        // Check if player exists (first player on creation)
        if (data.players.length > 0 && !playerNameParam) {
          setPlayer(data.players[0]);
        } else if (playerNameParam) {
          // Player was just created, get the latest player
          setPlayer(data.players[data.players.length - 1]);
        }
      } catch (err) {
        setError((err as Error).message);
      } finally {
        setLoading(false);
      }
    };

    fetchStory();
    // Poll for updates every 2 seconds
    const interval = setInterval(fetchStory, 2000);
    return () => clearInterval(interval);
  }, [storyId, playerNameParam]);

  const handleAddTurn = async (content: string) => {
    if (!player || !story) return;

    setIsAddingTurn(true);
    try {
      const response = await fetch('/api/turns', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          storyId: story.id,
          playerId: player.id,
          content,
        }),
      });

      if (!response.ok) throw new Error('Failed to add turn');

      // Fetch updated story
      const storyResponse = await fetch(`/api/stories/${storyId}`);
      if (!storyResponse.ok) throw new Error('Failed to fetch story');

      const updatedStory = await storyResponse.json();
      setStory(updatedStory);
    } catch (err) {
      setError((err as Error).message);
    } finally {
      setIsAddingTurn(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-100 to-blue-100 flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">📖</div>
          <p className="text-2xl font-bold text-purple-900">Loading story...</p>
        </div>
      </div>
    );
  }

  if (error || !story || !player) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-100 to-pink-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-lg p-8 text-center max-w-md">
          <div className="text-6xl mb-4">❌</div>
          <p className="text-2xl font-bold text-red-900 mb-4">Error</p>
          <p className="text-gray-700 mb-6">{error || 'Could not load story'}</p>
          <a
            href="/"
            className="inline-block bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 px-6 rounded-lg"
          >
            Back to Home
          </a>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-100 via-pink-100 to-blue-100">
      <StoryEditor
        story={story}
        currentPlayer={player}
        onAddTurn={handleAddTurn}
        isLoading={isAddingTurn}
      />
    </div>
  );
}
